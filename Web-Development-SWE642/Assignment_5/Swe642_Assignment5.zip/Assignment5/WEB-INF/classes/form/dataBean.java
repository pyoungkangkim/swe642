/*Ajay Adithya Rajagopal
 * Bean class to handle mean and sd
 */

package form;

public class dataBean {
	private double mean;
	private double sd;
	
	public double getMean() {
		return mean;
	}
	public void setMean(double mean) {
		this.mean = mean;
	}
	public double getSd() {
		return sd;
	}
	public void setSd(double sd) {
		this.sd = sd;
	}
	
	
}
