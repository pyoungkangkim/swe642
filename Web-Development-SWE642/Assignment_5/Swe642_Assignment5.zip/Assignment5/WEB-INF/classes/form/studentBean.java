package form;

public class studentBean {

	public studentBean()
	{
		
	}
	
	
    private String FName;
    private String LName;
    private String StudentID;
	private String Street;
    private String Zip;
    private String City;
    private String State;
    private String Phone;
    private String Email;
    private String URL;
    private String Date;
    private String ThingsLiked;
    private String HowInterested;   
    private String GradMonth;
    private String Year;
    private String Likelihood;
    private String Data;  
    private String Mean;
    private String StandardDev;
    private String comments;
    
	public String getFName() {
		return FName;
	}
	public void setFName(String firstName) {
		FName = firstName;
	}
	public String getLName() {
		return LName;
	}
	public void setLName(String lastName) {
		LName = lastName;
	}
	public String getStudentID() {
		return StudentID;
	}
	public void setStudentID(String studentID) {
		StudentID = studentID;
	}
	public String getStreet() {
		return Street;
	}
	public void setStreet(String street) {
		Street = street;
	}
	public String getZip() {
		return Zip;
	}
	public void setZip(String zip) {
		Zip = zip;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getPhone() {
		return Phone;
	}
	public void setPhone(String phone) {
		Phone = phone;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getUrl() {
		return URL;
	}
	public void setUrl(String url) {
		URL = url;
	}
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	public String getThingsliked() {
		return ThingsLiked;
	}
	public void setThingsliked(String thingsLiked) {
		ThingsLiked = thingsLiked;
	}
	public String getHowinterested() {
		return HowInterested;
	}
	public void setHowinterested(String howInterested) {
		HowInterested = howInterested;
	}
	public String getGradMonth() {
		return GradMonth;
	}
	public void setGradMonth(String gradMonth) {
		GradMonth = gradMonth;
	}
	public String getYear() {
		return Year;
	}
	public void setYear(String year) {
		Year = year;
	}
	public String getLikelihood() {
		return Likelihood;
	}
	public void setLikelihood(String likelihood) {
		Likelihood = likelihood;
	}
	public String getData() {
		return Data;
	}
	public void setData(String data) {
		Data = data;
	}
	public String getMean() {
		return Mean;
	}
	public void setMean(String mean) {
		Mean = mean;
	}
	public String getStandardDev() {
		return StandardDev;
	}
	public void setStandardDev(String standardDev) {
		StandardDev = standardDev;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
}
