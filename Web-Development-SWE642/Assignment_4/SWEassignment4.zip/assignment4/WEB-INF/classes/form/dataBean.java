package form;
/* Ajay Adithya Rajagopal
 * This class is used to set and get mean and standard deviation from 10 numbers
 */
public class dataBean {
	private double mean;
	private double sd;
	public dataBean(){
	}
	
	public double getMean() {
		return mean;
	}
	public void setMean(double mean) {
		this.mean = mean;
	}
	public double getSd() {
		return sd;
	}
	public void setSd(double sd) {
		this.sd = sd;
	}
}
